#include "classmeal.h"
main(){
	meal breakfast("bread",250),lunch("biryani",2500),dinner("pizza",5000),total;
	total = breakfast + lunch + dinner ;
	cout << total;
}
