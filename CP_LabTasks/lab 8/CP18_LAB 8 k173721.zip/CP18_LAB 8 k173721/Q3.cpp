#include<iostream>
using namespace std;

class Time
{
	int hours, min, sec;
	public:
		Time(int h, int m, int s)
		{
			hours=h;
			min=m;
			sec=s;
		}
		Time(){
		}
		
		print()
		{
			cout<<"Hours:Minutes:Seconds = "<<hours<<":"<<min<<":"<<sec;
		}
		
		Time operator+(Time &obj2)
		{
			Time temp;
			temp.hours=hours+obj2.hours;
			temp.min=min+obj2.min;
			temp.sec=sec+obj2.sec;
			return temp;
		}
		
		 operator<(Time &obj2)
		{
			if(hours==obj2.hours && min==obj2.min && sec==obj2.sec)
			cout<<"They Are same"<<endl;
			else
			cout<<"They are differenet"<<endl;
		}
};

main()
{
	//Time t1,t2,t3;
	
	Time t1(10, 10, 10);
	Time t2(10, 10 , 10);
	Time t3;
	t3=t1+t2;
	t1<t2;
	t3.print();
}
