#include<iostream>

using namespace std;

class Phonecall
{
	private:
		int  phone;
		int min;
		int rate;
		
	public:
		void phones(int p,int m)
		{
			phone=p;
			min=m;
			rate=1.2*min;
		}
		
		bool operator==(Phonecall p1)
		{
			if(phone==p1.phone)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		
};

int main()
{
	Phonecall p[10];
	int num[10];
	int min[10];
	for(int i=0;i<10;i++)
	{
		cout<<"Enter Phone Number "<<i+1<<" :"<<endl;
		cin>>num[i];
		cout<<"Enter the minutes of phonecall:"<<endl;
		cin>>min[i];
		p[i].phones(num[i],min[i]);
		 
	}
	
	for(int i=0;i<10;i++)
	{
		for(int j=i+1;j<10;j++)
		{
			if(p[i]==p[j])
			{
				cout<<"\nPhone call "<<i+1<<" is equal to phone call "<<j+1;
			}
		}
	}
	
}
