#include<iostream>
using namespace std;

class primeNumber
{
	int prime;
	public:
	primeNumber()
	{
		prime=1;
	}
	
	primeNumber(int x)
	
	{
		prime=x;
	}
	
	printnumber()
	{
		cout<<"Prime Number: "<<prime;
	}
	
	operator++()
	{
		int i,j=2;
  		for(i=prime+1;i<9000;i++)
  	 	{
    		for(j=2;j<i;j++)
    	  	{
     			if(i %j==0)
     	  		{
					 break;
     	  		}
     	  	}
     		if(i==j || i==1)
       		{
       			cout<<"\t"<<i;
    			break;		
    		} 	
    	}  
    	
    prime=i;	
	}
	
	operator--()
	{
		/*
			int i,j=2;
  		for(i=prime-1;i<3000;i--)
  	 	{
    		for(j=2;j<i;j++)
    	  	{
     			if(i %j==0)
     	  		{
					 break;
     	  		}
     	  	}
     		if(i==j || i==1)
       		{
       			cout<<"\t"<<i;
    			break;		
    		} 	
    	} 
		prime=i;
	*/		
    	}
		  
};

main()
{
	primeNumber obj;
	obj=primeNumber(19);
	++obj;
	//--obj;
	obj.printnumber();
}
