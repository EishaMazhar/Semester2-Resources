#include<iostream>
using namespace std;
class meal{
		string name;
		int cal;
	public:
		set(string n,int c){
			name = n;
			cal = c;	
}
		meal(){
			name="total_calorie";
			cal= 0 ;
		}
		meal(string n,int c){
			name = n;
			cal = c;
		}
	
		friend ostream& operator << ( ostream&os,meal);
		friend istream& operator >> ( istream&os,meal);
	 	friend operator += (meal,meal);
	friend meal operator + (meal a,meal m);
	int to(meal m){
		return m.cal;
	}
	
};

operator += (meal m,meal a){
			m.cal += a.cal;
		}
	ostream& operator << ( ostream&os,meal m){
			os<<"NAME " << m.name<<endl;
			os <<"CALORIE "<< m.cal<<endl;
			return os;	
		}
	istream& operator >> ( istream&os,meal m){
			cin>>m.name>>m.cal;
			return os;	
		}
meal operator + (meal a,meal m){
			meal temp;
			temp.cal=a.cal + m.cal;
			return temp;
		}

