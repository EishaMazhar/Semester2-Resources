#include "classmeal.h"
main(){
	meal a[21],total,t;
	string name;
	int cal,c=0;
	for(int i=0;i<21;i++){
		cout<<"enter the name and calorie for "<<i+1<<" meal\n";
		cin>>name>>cal;
		a[i].set(name,cal);
		total = a[i]+ t;
		c += a[i].to(total);
}
	cout << "TOTAL CALORIE" << c;
}
