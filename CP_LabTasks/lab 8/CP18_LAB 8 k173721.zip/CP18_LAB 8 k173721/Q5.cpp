#include<iostream>

using namespace std;

class NumDays
{
	int workhours;
	float days;
	
	public:
		 NumDays(int w):workhours(w){
		 }
		 NumDays(){
		 }
		 void dayscal()
		 {
		 	days =(float) workhours / 8;
		 }
		 void disp()
		 {
		 	cout<<"			Days= "<<days<<"\n";
		 }
		 NumDays operator + (NumDays a)
		 {
		 	NumDays temp;
		 	temp.workhours=a.workhours+workhours;
		 	return temp;
		 }
		 NumDays operator - (NumDays a)
		 {
		 	NumDays temp;
		 	temp.workhours=a.workhours-workhours;
		 	return temp;
		 }
		 void operator ++()
		 {
		 	workhours=workhours+1;
		 }
		 void operator --()
		 {
		 	workhours=workhours-1;
		 }
		 
};

int main()
{
	NumDays a(10),b(20),c;
	c=a+b;
}
