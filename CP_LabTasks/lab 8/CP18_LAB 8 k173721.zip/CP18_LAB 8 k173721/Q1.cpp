#include<iostream>
using namespace std;
class  details;

class location
{
	
	public:
		int latitude;
	int longitude;
		//details d1;
		location(int la, int lo)
		{
			latitude=la;
			longitude=lo;
		}
		location()
		{
			
		}
		
		
		const display()
		{
			cout<<"latitude: "<<latitude<<endl;
			cout<<"longitude: "<<longitude<<endl;
		}
		
		operator++()
		{
			++latitude;
			++longitude;
		}
		
		location operator++(int)
		{
			location temp;
			temp.latitude=latitude;
			temp.longitude=longitude;
			latitude++;
			longitude++;
			return temp;
		}
		
		location operator+(int x)
		{
			location temp;
			temp.latitude=latitude+10;
			temp.longitude=longitude+10;
			return temp;
		}
		
	friend location operator +(location);
};

location operator+( int a, location &obj)
{
	 		location temp;
			temp.latitude=obj.latitude+a;
			temp.longitude=obj.longitude+a;
			return temp;
}

class details
{
	
};

main()
{
	location obj1, obj2, obj3;
	
	obj1=location(10, 20);
	obj2=location(5, 30);
	obj3=location(90, 90);
	++obj1;
	obj2=obj1++;
	obj2.display();
	
	obj2=obj1+10;
	obj2.display();
	
	obj2=10+obj1;
	obj2.display();
	
	
	
}
