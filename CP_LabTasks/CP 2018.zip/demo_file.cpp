

#include <iostream>
#include <fstream>
using namespace std;

class file_demo{
public:
 string name;
 int id;
file_demo()
{
}
 file_demo(int a,string n)
 {
 	name=n;
 	id=a;
 }
 void showData()
 {
  cout << "Name: " << name << endl;
  cout << "Id: " << id << endl;
 }
};

int main(){
file_demo d(36,"umer");

 ofstream os("demo.txt");//Open file in binary mode.
 cout << "This data has been store in the file demo.bin in directory you've \ncreated your project\n\n" << endl;
 
 os.write((char*)&d, sizeof(d));

 os.close();

 //PRINTING SAVED DATA IN FILE.
 
 ifstream is("d.txt");
  
 is.read((char*)&d,sizeof(d));
 
 cout<<d.id<<endl<<d.name<<endl;
 return 0;
}
