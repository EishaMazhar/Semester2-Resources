#include <iostream>
using namespace std;
 
class Home {
   private:
      int feet;             
      int inches;                 
   public:
      // required constructors
      Home() {
         feet = 0;
         inches = 0;
      }
      Home(int f, int i) {
         feet = f;
         inches = i;
      }
      friend ostream &operator<<( ostream &output, const Home &H ) { 
         output << "F : " << H.feet << " I : " << H.inches;
         return output;            
      }

      friend istream &operator>>( istream  &i, Home &H ) { 
         i >>H.feet >> H.inches;
         return i;            
      }
};

int main() {
   
   int a;
   cout << a<<endl;
   Home  h;
   cout << "Enter the value of Home feet and inches: " << endl;
   cin >> h;
   cout << "Home :" << h << endl;

   return 0;
}
