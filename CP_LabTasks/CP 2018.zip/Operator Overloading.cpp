#include <iostream>

using namespace std;

class test{
	private:
		int a;
		int b;
		
	public:
		
		test()
		{
			
		}
		test(int a,int b)
		{
			this->a=a;
			this->b=b;
		}
		
		test operator + (test t)
		{
			test temp;
			temp.a=a+t.a;
			temp.b=b+t.b;
			
			return temp;
			
		}
		
		
		test operator - (test t)
		{
			test temp;
			temp.a=a-t.a;
			temp.b=b-t.b;
			
			return temp;
			
		}
		
			test operator * (test t)
		{
			test temp;
			temp.a=a*t.a;
			temp.b=b*t.b;
			
			return temp;
			
		}
		
			test operator / (test t)
		{
			test temp=t;
			
			if (t.a!=0 && t.b!=0)
			{
			test temp;
			temp.a=a/t.a;
			temp.b=b/t.b;
		    }
			return temp;
			
		}
		
		
		
	  test operator ++()
	  {
	  	a++;
	  	b++;
	  	return *this;
	  }
	  
	  
	test operator ++(int)
	  {
	  	a++;
	  	b++;
	  	return *this;
	  }
	  
	  
	   test operator --()
	  {
	  	a--;
	  	b--;
	  	return *this;
	  }
	  
	   test operator --(int)
	  {
	  	a++;
	  	b++;
	  	return *this;
	  }
	 
	  test operator = (test t)
	  {
	 
	  	a=t.a;
	  	b=t.b;
		
		
		return *this;
	  }
	  
	bool operator ==(test t)
	{
		return (a==t.a && b==t.b);
	}
	  
	  
	bool operator !=(test t)
	{
		return (a!=t.a && b!=t.b);
	}
	
	bool  operator <=(test t)
	{
		return (a<t.a && b<t.b) || (a==t.a && b==t.b);
	}
	
	bool operator <(test t)
	{
		return (a<t.a && b<t.b);
	}
	
	bool operator >(test t)
	{
		return (a>t.a && b>t.b);
	}
	
	bool  operator >=(test t)
	{
			return (a>t.a && b>t.b) || (a==t.a && b==t.b);
	}

display()
{
cout<<a;
cout<<b;	
}	
	
	friend ostream& operator <<(ostream& o, test& t);
	friend istream& operator >>(istream& i, test& t);	 
	friend test operator +(int i, test t);
	
};

test operator +(int i, test t)
{
test temp;
temp.a=t.a+i;
temp.b=t.b+i;

return temp;
	
}

ostream& operator <<(ostream& o, test& t)
{
	o<<t.a<<endl;
	o<<t.b<<endl;
	return o;
}


istream & operator >> (istream &i,  test& t)
{
    i >> t.a;
    i >> t.b;
    return i;
}


int main()
{
	test t1,t2(2,3),t3;
	
	cin>>t1;
    
    cout<<"Pre decrement:"<<endl;
    --t1;
    cout<<t1;
    
    cout<<"Post increment:"<<endl;
	t1++;
    cout<<t1;
    
    cout<<"Addition:"<<endl;
    t3=t1+t2;
    cout<<t3;
    
    cout<<"Equality condition check:"<<endl;
    if(t1==t2)
    {
    	cout<<"Equal"<<endl;
	}
	else
	{
		cout<<"Not Equal"<<endl;
	}
	
	 cout<<"Less then condition check:"<<endl;
	if(t1<t2)
    {
    	cout<<"t1 is less than t2"<<endl;
	}
	else
	{
		cout<<"t1 is not less than t2"<<endl;
	}
    
	return 0;
}
