#include <iostream>
using namespace std;

class Pet { public: 

 virtual void Random(){
	cout<<"pet random function:"<<endl;

}
};
class Dog : public Pet {};
class Cat : public Pet {
public:
virtual	 void Random(){
	cout<<"cat random function:"<<endl;

}



};

int main() {
  Pet* b = new Cat; 
  Pet p;
  Dog* d1 = static_cast<Dog*>(b);

  Cat* d2 = static_cast<Cat*>(&p);
//  cout << "d1 = " << d1 << endl; //fails gracefully 
//  cout << "d2 = " << d2 << endl; //success: returns pointer address
d2->Random();
b->Random();



} 
