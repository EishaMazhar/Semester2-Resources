#include<iostream>
using namespace std;
main()
{
	cout<<"*** Program to find the product of 3 numbers ***";
	int a,b,c;                                                //declaration
	
	cout<<"\n\nenter a : ";                        //first number input
	cin>>a;
	
	cout<<"enter b : ";                            //second number input
	cin>>b;
	
	cout<<"enter c : ";                            //third number input
	cin>>c;
	
	cout<<"the product is : "<<a*b*c;         //print the product of three variables
}
