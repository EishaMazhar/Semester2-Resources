#include<iostream>
using namespace std;
main()
{
	int a=100;
	cout<<"1. "<<a<<endl;
	a=a/2;
	cout<<"2. "<<a<<endl;
	a+=2;
	cout<<"3. "<<a<<endl;
	a=a/2;
	cout<<"4. "<<a<<endl;
	a+=2;
	cout<<"5. "<<a<<endl;
}
