#include<iostream>
using namespace std;
perfect_square(int n)
{
	int a;
	for(a=1;a<=n;a++)
	{
		if(n==a*a)
		{
			cout<<n<<" ";
		}
	}
	
}
main()
{
	int n1,n2,i;
	cout<<"           ** Program to check a perfect square **   \n\n";
	cout<<"enter min range number : ";
	cin>>n1;
	cout<<"enter max range number : ";
	cin>>n2;
	for(i=n1;i<=n2;i++)
	{
		perfect_square(i);
	}
}
