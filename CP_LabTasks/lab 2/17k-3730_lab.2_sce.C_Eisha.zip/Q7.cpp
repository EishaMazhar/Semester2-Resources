#include<iostream>
using namespace std;
reverse(int a)
{
	int rem=0;
	if(a!=0)
	{
		rem=a%10;
    	cout<<rem;
	    a=a/10;
	    reverse(a);
	}
}
main()
{
	int a;
	cout<<"          ** Program to reverse an integer ** \n\n";
	cout<<"Enter a number : ";
	cin>>a;
	reverse(a);
}
