#include<iostream>
using namespace std;
read_parameters(int *l,int *w)
{
	cout<<"Enter the length : ";
	cin>>*l;
	cout<<"Enter the width : ";
	cin>>*w;
}
int Area(int l,int w)
{
	int area=l*w;
	return area;
}
int Parameter(int l,int w)
{
	int para=2*(l+w);
	return para;
}
main()
{
	cout<<"           ** Program to find Area And Parameter of rectangle **  \n\n";
	int length=0,width=0;
	read_parameters(&length,&width);
	int a=Area(length,width);
	int p=Parameter(length,width);
	cout<<"\nThe area of rectangle is : "<<a;
	cout<<"\nThe parameter of rectangle is : "<<p;
}
