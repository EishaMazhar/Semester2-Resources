#include<iostream>
using namespace std;
convert(int no,int *h,int*m,int*s)
{
	*h=no/3600;
	no%=3600;
	*m=no/60;
	no%=60;
	*s=no;
}
main()
{
	int no=0,sec=0,min=0,hour=0;
	cout<<"            ** Program to convert seconds to equivalent HH:MM:SS ** \n\n";
	cout<<"Enter the time in seconds : ";
	cin>>no;
	convert(no,&hour,&min,&sec);
	cout<<"\nThe time in HH:MM:SS format is : \n\n\t"<<hour<<" hour, "<<min<<" minuite, "<<sec<<" seconds.( "<<hour<<":"<<min<<":"<<sec<<" )";
	
}
