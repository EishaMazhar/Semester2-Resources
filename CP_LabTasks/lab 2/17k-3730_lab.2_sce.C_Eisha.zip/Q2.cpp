#include<iostream>
#include<stdlib.h>
using namespace std;
int* divisors(int *a)
{
	int i=0, x=*a ,k=0,j=0;
	int *p=new int[50];
	for( i=1 ; i <= x ; i++ )
	{
		if( x % i == 0 )
		{
            p[k]=i;
            k++;
		}
	}
	return p;
}
main()
{
	int a,j=0;
	cout<<"         ** Program to find divisors ** \n\n";
	cout<<"Enter the number : ";
	cin>>a;
	int *p=divisors(&a);
	while(p[j]!='\0')
		{
			cout<<p[j]<<" ";
			j++;
		}
	delete(p);
}
