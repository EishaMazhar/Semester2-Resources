#include<iostream>
using namespace std;
int is_prime(int i)
{
	int a,flag=0;
	for(a=2;a<=i/2;a++)
	{
		if(i%a==0)
		{
			flag=1;
			break;
		}
	}
	if(flag==0)
	return i;
	
}
main()
{
	int no,i;
	cout<<"      ** program to print prime numbers b/w 2 to 100 ** \n\n";
	for(i=2;i<=100;i++)
	{
		if(is_prime(i)!=0)
		cout<<is_prime(i)<<" ";
	}
}
